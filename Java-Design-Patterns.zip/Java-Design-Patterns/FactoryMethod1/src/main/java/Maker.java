interface WatchMaker {
    Watch createWatch();
}
