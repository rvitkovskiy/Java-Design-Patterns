import java.util.Date;

public class RomeWatch implements Watch {
    public void showTime() {
        //TOD....
        System.out.println("VII-XX");

    }
}
