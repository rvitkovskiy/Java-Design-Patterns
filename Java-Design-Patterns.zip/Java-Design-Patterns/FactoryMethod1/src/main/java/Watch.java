interface Watch{
    void showTime();
}
 