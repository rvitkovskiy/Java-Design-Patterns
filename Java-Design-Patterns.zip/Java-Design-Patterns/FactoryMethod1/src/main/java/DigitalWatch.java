import java.util.Date;

public class DigitalWatch implements Watch {
    public void showTime() {
        //TOD....
        System.out.println(new Date());
    }
}
