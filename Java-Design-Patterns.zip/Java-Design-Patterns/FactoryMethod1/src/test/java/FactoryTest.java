
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FactoryTest {
    @Test
    public void Test() {
        String watch = "Digital";
        FactoryMethod watchmaker = new FactoryMethod();
        assertTrue(FactoryMethod.getMakerByName("Digital")instanceof DigitalWatchMaker);
    }
}

