    import org.junit.jupiter.api.Test;

    import static org.junit.jupiter.api.Assertions.*;

public class AdapterTest {
    @Test
    public void Test(){
        VectorAdapterFromRaster vector = new VectorAdapterFromRaster();
        VectorAdapterFromRaster2 vector2 = new VectorAdapterFromRaster2();
        assertEquals(vector2.drawLine(), "aaa" );

    }
}
