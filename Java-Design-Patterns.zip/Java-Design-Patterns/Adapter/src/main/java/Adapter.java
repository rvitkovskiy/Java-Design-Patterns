import java.nio.file.FileSystemNotFoundException;

public class Adapter {
    public static void main(String[] args) throws FileSystemNotFoundException {
         //#1
        VectorGraphics g1 = new VectorAdapterFromRaster();
        g1.drawLine();
        g1.drawSquare();
        VectorGraphics g2 = new VectorAdapterFromRaster2();
        g1.drawLine();
        g1.drawSquare();

    }
}
