public class VectorAdapterFromRaster2 extends RasterGraphics implements VectorGraphics{
    RasterGraphics raster = new RasterGraphics();
    public String drawLine() {
        return raster.drawRasterLine();
    }

    public void drawSquare() {
        raster.drawRasterSquare();
    }
}