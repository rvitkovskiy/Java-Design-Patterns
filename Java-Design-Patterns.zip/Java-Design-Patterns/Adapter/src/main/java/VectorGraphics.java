interface VectorGraphics {
    String drawLine();
    void drawSquare();
}
