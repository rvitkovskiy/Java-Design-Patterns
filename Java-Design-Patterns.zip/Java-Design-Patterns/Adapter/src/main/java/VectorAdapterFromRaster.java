public class VectorAdapterFromRaster extends RasterGraphics implements VectorGraphics {
    public String drawLine() {
        return  drawRasterLine();
    }

    public void drawSquare() {
    drawRasterSquare();
    }
}
