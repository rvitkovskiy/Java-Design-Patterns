public class RasterGraphics {
    String drawRasterLine(){
        String type = "aaa";
        System.out.println();
        return type;
    }
    void drawRasterSquare(){
        System.out.println("Drawing square");
    }
}
