import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BridgeTest {



    @Test
    public void BridgeTest() {

        Shape triangle = new Triangle(new Orange());
        assertEquals(triangle.draw(), "Triangle Color is Orange");


    }
}