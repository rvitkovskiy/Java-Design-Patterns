

    public class Orange implements Color {

        public String fill() {
        return "Color is Orange";
    }

}