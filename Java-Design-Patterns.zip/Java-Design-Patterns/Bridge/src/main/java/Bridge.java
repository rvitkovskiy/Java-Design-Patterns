public class Bridge {

    public static void main(String[] args) {

        Shape square = new Square(new Brown());
        System.out.println(square.draw());

        Shape triangle = new Triangle(new Orange());
        System.out.println(triangle.draw());
    }
}