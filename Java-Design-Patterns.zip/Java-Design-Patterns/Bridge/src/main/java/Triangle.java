public class Triangle extends Shape {




    public Triangle(Color color) {

        super(color);

    }


    public String draw() {

        return "Triangle "+ color.fill();

    }
}
