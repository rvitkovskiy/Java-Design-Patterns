
public interface Color {

        String fill();

}