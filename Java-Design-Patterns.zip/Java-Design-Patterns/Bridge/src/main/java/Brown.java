public class Brown implements Color {

        public String fill() {
            return "Color is Brown";

        }



}