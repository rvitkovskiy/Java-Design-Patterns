public interface Select {
}
