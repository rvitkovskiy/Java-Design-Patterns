public class WindowsSelect implements Select {
}
