public class MacButton implements Button {
}