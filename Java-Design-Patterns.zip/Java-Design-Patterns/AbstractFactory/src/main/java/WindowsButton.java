public class WindowsButton implements Button {
}
