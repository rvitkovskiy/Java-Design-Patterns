import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestFactory {

    @Test
    public void shouldPass() {

        WindowsGUIFactory wgf = new WindowsGUIFactory();

        assertTrue(wgf.createSelect() instanceof  Select);
        assertTrue(wgf.createTextField() instanceof  TextField);
        assertTrue(wgf.createButton() instanceof  Button);


    }


}
