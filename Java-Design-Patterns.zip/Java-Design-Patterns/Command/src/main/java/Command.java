interface Command {
    void execute();
}