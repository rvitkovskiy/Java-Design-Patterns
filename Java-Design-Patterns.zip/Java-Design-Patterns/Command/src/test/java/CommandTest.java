import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions.*;

public class CommandTest {
    @Test
    public void ShouldPass(){
        Light lamp = new Light();

        Command switchOn = new SwitchOnCommand(lamp);
        Command switchOff = new SwitchOffCommand(lamp);

        Switch mySwitch = new Switch();
        mySwitch.register("on", switchOn);
        mySwitch.register("off", switchOff);

        mySwitch.execute("on");
        mySwitch.execute("off");
    }
}
