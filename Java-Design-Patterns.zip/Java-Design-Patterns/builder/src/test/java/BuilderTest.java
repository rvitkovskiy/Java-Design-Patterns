import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BuilderTest {

    @Test
    public void shouldPass() {
        Car car = new CarBuilder()
                .buildMake("mercedes")
                .buildTransmission(CarBuilder.Transmission.AUTO)
                .buildMaxSpeed(280)
                .build();

        assertEquals("mercedes",car.getMake());
        assertEquals(CarBuilder.Transmission.AUTO, car.getTransmission());
        assertEquals(280,car.getMaxSpeed());
    }
    }

