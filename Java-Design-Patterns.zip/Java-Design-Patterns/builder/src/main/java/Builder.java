public class Builder {
    public static void main(String[] args) {
    Car car = new CarBuilder()
            .buildMake("mercedes")
            .buildTransmission(CarBuilder.Transmission.AUTO)
            .buildMaxSpeed(280)
            .build();
        System.out.println(car);
    }
}

