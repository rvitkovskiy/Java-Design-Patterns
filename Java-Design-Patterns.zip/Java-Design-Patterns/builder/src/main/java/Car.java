

class Car {
    String make;
    CarBuilder.Transmission transmission;
    int maxSpeed;

    public String getMake() {
        return make;
    }

    public CarBuilder.Transmission getTransmission() {
        return transmission;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public void setMake(String make) {
        this.make = make;
    }
    public void setTransmission(CarBuilder.Transmission transmission) {
        this.transmission = transmission;
    }
    public void setMaxSpeed(int maxSpeed){
        this.maxSpeed = maxSpeed;
    }

    public String toString(){
        return "Car [make = " + make + ",transmission= " + transmission + ", maxSpeed=" +maxSpeed+"]";
    }

}
