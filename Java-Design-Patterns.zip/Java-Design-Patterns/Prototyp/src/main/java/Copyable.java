interface Copyable {
    Object copy();
}
