public class Prototype {
    public static void main(String[] args) {


        Human original = new Human (12,"Vasya");
        Human copy = (Human) original.copy();

        System.out.println(original);
        System.out.println(copy);
    }
}