public interface Sort {
    int[] sort(int[] e);

}
