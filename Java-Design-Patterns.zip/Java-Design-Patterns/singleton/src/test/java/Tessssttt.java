import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.Assertions.*;

public class Tessssttt {
    @Test

    public void ShouldPass() {
        Telewizor telewizor = new Telewizor();
        telewizor.turnOn();

        telewizor.changeChanel();
        assertEquals(telewizor.chanel,2);


        telewizor.whichChanel();
        telewizor.turnOff();
        telewizor.whichChanel();
        telewizor.turnOn();
        telewizor.whichChanel();



    }
    @Test
    public void shouldPass2 () {

        Telewizor telewizor = new Telewizor();
        assertFalse(telewizor.isTurnedOn());
        telewizor.turnOn();
        assertTrue(telewizor.isTurnedOn());
        telewizor.turnOff();
        assertFalse(telewizor.isTurnedOn());


    }

}






