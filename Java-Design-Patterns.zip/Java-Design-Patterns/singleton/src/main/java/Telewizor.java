public class Telewizor {
    public int chanel;
    public boolean turnedOn;

    public Telewizor() {
        this.chanel = 1;
        this.turnedOn = false;
    }

    public void turnOn(){
        if(turnedOn){
            System.out.println("Telewizor jest wlaczony");
        }
        else{
            this.turnedOn = true;
            System.out.println("Wlaczenie telewizora ...");
        }
    }

    public void turnOff(){
        if(!turnedOn){
            System.out.println("Telewizor jest wylaczony");
        }
        else{
            this.turnedOn = false;
            System.out.println("Wylaczenie telewizora ...");
        }
    }
    public void changeChanel(){
        System.out.println("Chanel changed");
        this.chanel = this.chanel+1;
    }

    public boolean isTurnedOn(){
        return this.turnedOn;
    }



    public void whichChanel(){
        if (!this.turnedOn){
            System.out.println("Najpierw wlacz telewizor!");
        }
        else{
            System.out.println("Chanel number " + this.chanel);
        }
    }

}
