import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FlyweightTest {
    @Test
    public void ShouldPassFlyweight(){
        NameFactory names = new NameFactory();
        Name n1 = new Name("Roman");
        names.addName(n1);

        PhoneNumberFactory f = new PhoneNumberFactory();

        f.getPhoneNumberHashMap().put(n1, new PhoneNumber("Vitkovskiy"));
        f.addNumber(n1, "98989898900");
        f.addNumber(n1, "7678987809");

        assertTrue(n1.getName() == "Roman");
    }
}
