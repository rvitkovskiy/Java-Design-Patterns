class CurrentConditionsDisplay implements Observer {
    private float temperature;
    private float humidity;
    private int pressure;


    public void update(float temperature, float humidity, int pressure) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        display();
    }

    public void display() {
        System.out.printf("Current value:%.1f C and %.1f %% humidity, pressure %d m. m.\n", temperature, humidity, pressure);
    }
}
