package test.java;

public class Test {

    public void ShouldPass(){
                Telewizor telewizor = new Telewizor();
                telewizor.turnOn();
                telewizor.whichChanel();
                telewizor.changeChanel();
                telewizor.changeChanel();
                telewizor.whichChanel();
                telewizor.turnOff();
                telewizor.whichChanel();
                telewizor.turnOn();
                telewizor.whichChanel();






    }

}


