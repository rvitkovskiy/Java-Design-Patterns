import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class Testing {
    @Test
    public void Testing(){
        SubExpression a = new Expression();
        a.add(new Expression());
        a.getSubExpression(0).add(new IntegerValue(3));
        assertNotNull(a.getSubExpression(0).getSubExpression(0));
    }
}